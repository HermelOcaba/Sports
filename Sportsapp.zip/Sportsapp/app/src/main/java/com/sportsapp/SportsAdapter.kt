package com.sportsapp.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.sportsapp.R
import com.sportsapp.model.Sport

class SportsAdapter(
    private val sports: List<Sport>,
    private val onItemClick: (Sport) -> Unit
) : RecyclerView.Adapter<SportsAdapter.SportViewHolder>() {

    inner class SportViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val sportName: TextView = itemView.findViewById(R.id.sport_name)
        private val sportIcon: ImageView = itemView.findViewById(R.id.sport_icon)

        fun bind(sport: Sport) {
            sportName.text = sport.name
            sportIcon.setImageResource(sport.iconRes)

            itemView.setOnClickListener {
                onItemClick(sport)
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): SportViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_sport, parent, false)
        return SportViewHolder(view)
    }

    override fun onBindViewHolder(holder: SportViewHolder, position: Int) {
        holder.bind(sports[position])
    }

    override fun getItemCount() = sports.size
}