package com.sportsapp.model

data class Sport(
    val name: String,
    val iconRes: Int,
    val actionId: Int
)